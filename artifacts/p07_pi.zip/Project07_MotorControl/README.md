# Project07_MotorControl

Basys3에서 JGB37-520 엔코더 DC 기어모터의 속도를 제어하는 학부 FPGA 프로젝트다. MATLAB에서
연속시간 모터 모델과 제어기를 설계하고, 이를 10 ms 주기의 고정소수점 제어기와 20 kHz PWM으로
변환해 Verilog-2001 RTL로 구현한다. MicroBlaze와 HDL Coder는 사용하지 않았다.

```text
speed reference -> fixed-point controller -> saturation -> 20 kHz PWM -> L298N -> motor
                         ^                                           |
                         +--------- Hall encoder C1 feedback --------+
```

## 구현 내용

- Digilent Basys3, Xilinx Artix-7
- JGB37-520, DC 12 V, 110 RPM, Hall encoder 내장 기어모터
- L298N H-bridge motor driver
- 100 Hz 고정소수점 PI와 20 kHz PWM
- Q16.16 제어기 계수와 64-bit 중간 연산
- PWM 출력 saturation과 conditional integration anti-windup
- C1 상승 에지 기반 속도 측정
- 내부 test plant, 외부 open-loop, 외부 closed-loop 모드
- arm 절차, 즉시 출력 차단 및 encoder stall fault

현재 실물 closed-loop 소스는 `Kp=0.9`, `Ki=6/s`, `Kd=0`인 PI다. Encoder 양자화에 민감한
D항은 첫 실물 시험에서 제외했고 derivative state는 향후 PID 비교를 위해 유지한다. 변경된 소스는
MATLAB과 XSim을 다시 통과시킨 뒤 별도 bitstream으로 사용한다.

## 현재 진행 상태

| 단계 | 결과 |
|---|---|
| MATLAB/Simulink 기준 모델 | 기존 PID PASS, 현재 PI 소스 재검증 대기 |
| XSim | 기존 PID 5개 testbench PASS, 현재 PI 소스 재검증 대기 |
| Vivado 2024.2 open-loop | Timing PASS, DRC Error 0 |
| Basys3 PWM/방향 출력 | PASS |
| L298N ENA 전달 | PASS |
| 실제 open-loop 모터 구동 | PASS |
| Encoder C1 전기 신호 | PASS |
| Encoder C1 FPGA 입력 | PASS |
| C1 CPR 및 RPM 환산 | 실측 완료 |
| PI closed-loop 실물 시험 | 남음 |

Open-loop 구현 결과는 setup slack `+3.142 ns`, hold slack `+0.122 ns`, LUT 84, FF 180,
DSP 1, BRAM 0이다.

## 배선

### 모터와 encoder

| 선 색상 | 기능 | 연결 |
|---|---|---|
| 빨강 | Motor M1 | L298N OUT1 |
| 흰색 | Motor M2 | L298N OUT2 |
| 파랑 | Encoder VCC | Basys3 3.3 V |
| 검정 | Encoder GND | 공통 GND |
| 초록 | Encoder C1 | Basys3 JA4 |
| 노랑 | Encoder C2 | 현재 미사용, 절연 |

### Basys3, L298N 및 전원

| 신호 | FPGA 핀 | 연결 |
|---|---|---|
| JA1 `motor_pwm` | J1 | L298N ENA, ENA 점퍼 제거 |
| JA2 `motor_in1` | L2 | L298N IN1 |
| JA3 `motor_in2` | J2 | L298N IN2 |
| JA4 `encoder_a` | G2 | Encoder C1 |
| GND | - | L298N, encoder, PSU 공통 GND |
| PSU +12 V | - | L298N +12V |

L298N의 `5V` 단자에는 외부 전원을 연결하지 않는다. 12 V는 L298N 모터 전원에만 연결하며
Basys3와 encoder에 연결하지 않는다.

## 스위치

- `SW0`: motor arm/enable. FPGA reset 또는 programming 뒤 OFF를 확인한 다음 ON해야 한다.
- `SW3:SW1`: 0~87.5% 범위의 open-loop duty 또는 closed-loop speed reference
- `SW4`: 외부 모드에서 C1 상승 에지의 1초 누적값을 LED에 이진수로 표시
- `BTNC`: reset 및 즉시 motor output 차단

25% open-loop 시험 설정은 `SW3=OFF`, `SW2=ON`, `SW1=OFF`이며 마지막에 `SW0`을 ON한다.

## 실물 측정 결과

| 시험 | 조건 | 결과 |
|---|---|---|
| 모터 단독 구동 | DC 3.0 V | CW 회전, 약 0.09~0.11 A |
| Basys3 JA1 | SW2+SW0 ON | 20 kHz, 약 25%, 약 0~3.3 V |
| Basys3 JA2/JA3 | 정방향 | 약 3.39 V / 약 0 V |
| L298N open-loop | PSU 12.0 V, 25% PWM | 저속 연속 회전, 약 0.07 A |
| Encoder C1 | 위 open-loop 조건 | 약 0~3.3 V, 90.75 Hz |
| 출력축 속도 | 10회전 85.0 s | 약 7.06 RPM |
| C1 환산값 | 같은 조건에서 동시 측정 | 약 771.4 rising edges/output revolution |

CPR은 같은 운전 조건에서 측정한 C1 주파수와 출력축 회전시간으로 계산했다.

```text
RPM = 600 / 85.0 = 7.06 RPM
C1 CPR = 90.75 * 85.0 / 10 = 771.375 ~= 771 pulse/rev
```

정격 110 RPM을 1.0 pu로 정하면 10 ms 동안의 C1 pulse 수는 다음과 같다.

```text
counts_full_scale = 771.375 * 110 / 60 * 0.01 = 14.14
ENCODER_COUNTS_FULL_SCALE = 14
```

정수값 14가 나타내는 실제 full-scale은 약 108.9 RPM이다. Closed-loop speed reference는
SW1부터 각각 약 13.6, 27.2, 40.8, 54.4, 68.1, 81.7, 95.3 RPM이다. 첫 실물 시험은
SW1만 ON한 약 13.6 RPM 목표에서 시작한다.

## Bitstream 사용

- `artifacts/laplace_open_loop.bit`: 현재 실물 open-loop 시험용
- `artifacts/laplace.bit`: 안전한 내부 plant 모드이며 실제 motor closed-loop용이 아님

Open-loop bitstream의 SHA-256은
`9bf58f6bfcd1f406bce613ec3f392c37465ec6198ddfbca1cf6781a89c0a8157`이다.
PI closed-loop bitstream은 아직 생성하지 않았다. 검증 없이 기존 `laplace.bit`을 실제 모터용으로
사용하지 않는다.

## 검증 및 빌드

MATLAB Online:

```matlab
cd Project07_MotorControl
RUN_MATLAB_CHECKS
```

Vivado 2024.2:

```text
python3 -m pip install -r requirements.txt
python3 tools/offline_check.py
python3 tools/run.py sim
python3 tools/run.py build
```

Open-loop commissioning만 다시 생성할 때는 다음 명령을 사용한다.

```text
python3 tools/run.py open-loop-sim
python3 tools/run.py open-loop-build
```

외부 모드는 `vivado/laplace_config.tcl`에서 설정한다. 설정 또는 RTL을 변경하면 MATLAB과 XSim을
다시 실행해야 closed-loop build gate를 통과할 수 있다.

## 안전

- 배선은 Basys3 OFF, PSU OUTPUT OFF 상태에서만 변경한다.
- 일반 오실로스코프 ground clip은 공통 GND에만 연결한다.
- OUT1/OUT2에 scope ground를 연결하지 않는다.
- 시험 시작은 PSU 12.0 V, current limit 0.5 A와 SW0 OFF 상태에서 진행한다.
- 정지, 과전류, 냄새 또는 과열이 발생하면 SW0 OFF 후 PSU OUTPUT을 OFF한다.

## 폴더

| 경로 | 내용 |
|---|---|
| `laplace/rtl` | PID, plant, encoder, PWM 및 Basys3 top |
| `laplace/tb` | 자동 PASS/FAIL testbench 5개 |
| `data` | PID 계수와 1,200-step 기준값 |
| `matlab` | 전달함수, 정수 Golden 및 Simulink 함수 |
| `vivado` | 프로젝트 생성, XSim 및 bitstream Tcl |
| `docs` | 설계 규칙, 하드웨어 배선 및 실물 측정 기록 |
| `artifacts` | bitstream, 구현 보고서, MATLAB 입력과 결과 |
| `HANDOFF.md` | 다음 작업자가 읽을 진행 기록 |

현재 `vivado/laplace_config.tcl`에는 `closed_loop`와 `ENCODER_COUNTS_FULL_SCALE=14`가 적용돼
있다. 다음 단계는 PI MATLAB/Simulink 검증과 XSim/Vivado closed-loop build, 목표 RPM 추종 및
부하 복원 시험이다.
